import {
  iosTransitionAnimation,
  shadow
} from "./chunk-WB2QOI75.js";
import "./chunk-GYSLJJOE.js";
import "./chunk-BYTETG5J.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-PHXTTYZJ.js.map
