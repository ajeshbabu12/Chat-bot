import {
  iosTransitionAnimation,
  shadow
} from "./chunk-D5AOWGR7.js";
import "./chunk-YPK352L4.js";
import "./chunk-JPAWISCV.js";
import "./chunk-BYTETG5J.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-4ee1a3af-6BNY22HD.js.map
